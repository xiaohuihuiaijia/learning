# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

from .image import ImageResizeTransform
