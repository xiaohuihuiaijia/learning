detectron2.layers package
=========================

.. automodule:: detectron2.layers
    :members:
    :undoc-members:
    :show-inheritance:
